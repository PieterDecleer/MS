# Copyright 2012 Philip Chimento

"""Sound the system bell, Wx implementation."""

import wx


def beep():
    """Sound the system bell."""
    wx.Bell()
