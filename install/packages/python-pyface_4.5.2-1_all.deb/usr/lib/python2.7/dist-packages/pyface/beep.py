# Copyright 2012 Philip Chimento

"""Sound the system bell."""

# Import the toolkit-specific version
from toolkit import toolkit_object
beep = toolkit_object('beep:beep')
