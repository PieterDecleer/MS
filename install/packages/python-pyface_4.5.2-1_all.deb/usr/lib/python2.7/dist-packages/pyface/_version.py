# THIS FILE IS GENERATED FROM PYFACE SETUP.PY
version = '4.5.2'
full_version = '4.5.2'
git_revision = '91c4cba'
is_released = True

if not is_released:
    version = full_version
