# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
Editor = toolkit_object('tasks.editor:Editor')
