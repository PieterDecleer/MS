# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
SplitEditorAreaPane = toolkit_object('tasks.split_editor_area_pane:'
                                     'SplitEditorAreaPane')

EditorAreaWidget = toolkit_object('tasks.split_editor_area_pane:'
                                    'EditorAreaWidget')
