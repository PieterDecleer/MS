

.. _example_numeric_source:

Numeric source example
--------------------------------------------

This script demonstrates how to create a numpy array data and
visualize it as image data using a few modules.



**Python source code:** :download:`numeric_source.py`

.. literalinclude:: numeric_source.py
    :lines: 7-


    