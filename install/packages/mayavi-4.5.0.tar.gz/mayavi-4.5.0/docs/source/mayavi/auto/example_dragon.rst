

.. _example_dragon:

Dragon example
--------------------------------------------------------------------


Viewing Stanford 3D Scanning Repository dragon model


**Python source code:** :download:`dragon.py`

.. literalinclude:: dragon.py
    :lines: 4-


    