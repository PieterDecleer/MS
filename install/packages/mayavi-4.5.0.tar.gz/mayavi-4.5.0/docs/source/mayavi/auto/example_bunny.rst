

.. _example_bunny:

Bunny example
--------------------------------------------------------------------


Viewing Stanford 3D Scanning Repository bunny model


**Python source code:** :download:`bunny.py`

.. literalinclude:: bunny.py
    :lines: 4-


    