

.. _example_lucy:

Lucy example
--------------------------------------------------------------------


Viewing Stanford 3D Scanning Repository lucy model


**Python source code:** :download:`lucy.py`

.. literalinclude:: lucy.py
    :lines: 4-


    