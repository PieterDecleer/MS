

.. _example_contour_contour:

Contour contour example
--------------------------------------------

This example shows how you can produce contours on an IsoSurface.


**Python source code:** :download:`contour_contour.py`

.. literalinclude:: contour_contour.py
    :lines: 4-


    