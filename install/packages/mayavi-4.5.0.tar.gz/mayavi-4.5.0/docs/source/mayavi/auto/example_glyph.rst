

.. _example_glyph:

Glyph example
--------------------------------------------


This script demonstrates using the Mayavi core API to add a VectorCutPlane,
split the pipeline using a MaskPoints filter and then view the filtered data
with the Glyph module.


**Python source code:** :download:`glyph.py`

.. literalinclude:: glyph.py
    :lines: 7-


    