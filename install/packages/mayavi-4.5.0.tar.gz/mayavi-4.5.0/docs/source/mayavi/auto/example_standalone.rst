

.. _example_standalone:

Standalone example
--------------------------------------------

A simple example of how you can use Mayavi without
using Envisage or the Mayavi Envisage application.



**Python source code:** :download:`standalone.py`

.. literalinclude:: standalone.py
    :lines: 6-


    