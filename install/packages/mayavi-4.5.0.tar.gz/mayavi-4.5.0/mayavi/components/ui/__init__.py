# Author: Judah De Paula
# Copyright (c) 2005-2008, Enthought, Inc.
# License: BSD Style.
